# regras padrão
